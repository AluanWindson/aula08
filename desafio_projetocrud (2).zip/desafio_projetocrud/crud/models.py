from django.db import models

# Create your models here.
from django.db import models

class Pessoa(models.Model):
    nome = models.CharField(max_length=30)
    idade = models.PositiveIntegerField(max_length=2)
    telefone = models.CharField(max_length=11)
    email = models.EmailField(80)
    qtd_pessoas = models.PositiveIntegerField(2)

    def __str__(self):
        return self.nome
class Avaliacao(models.Model):
    comentario = models.TextField(max_length=200)
    nota = models.IntegerField()
    criado_em = models.DateTimeField(auto_now_add=True)    