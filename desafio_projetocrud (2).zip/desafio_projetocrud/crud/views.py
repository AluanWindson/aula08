from django.shortcuts import render, redirect
from .models import Pessoa
from django.shortcuts import get_object_or_404

def adicionar_pessoa(request):
    if request.method == 'POST':
        nome = request.POST.get('nome')
        idade = request.POST.get('idade')
        telefone = request.POST.get('telefone')
        email = request.POST.get('email')
        qtd_pessoas = request.POST.get('qtd_pessoas')

        if nome and idade and telefone and email and qtd_pessoas:
            Pessoa.objects.create(
                nome=nome,
                idade=int(idade),
                telefone=telefone,
                email=email,
                qtd_pessoas=int(qtd_pessoas)
            )
            return redirect('lista_espera')  
        else:
            
            pass 

    return render(request, 'adicionar_pessoa.html')

def lista_espera(request):
    pessoas = Pessoa.objects.all()  # Busca todas as pessoas cadastradas
    contexto = {'pessoas': pessoas}
    return render(request, 'lista_espera.html', contexto)
    
def editar_pessoa(request, pessoa_id):
    pessoa = Pessoa.objects.get(id=pessoa_id)

    if request.method == 'POST':
        pessoa.nome = request.POST.get('nome')
        pessoa.idade = int(request.POST.get('idade'))
        pessoa.telefone = request.POST.get('telefone')
        pessoa.email = request.POST.get('email')
        pessoa.qtd_pessoas = int(request.POST.get('qtd_pessoas'))
        pessoa.save()
        return redirect('lista_espera')

    return render(request, 'editar_pessoa.html', {'pessoa': pessoa})
def deletar_pessoa(request, pessoa_id):
    pessoa = get_object_or_404(Pessoa, id=pessoa_id)
    if request.method == 'POST':
        pessoa.delete()
        return redirect('lista_espera')
    return render(request, 'confirmar_delete.html', {'pessoa': pessoa})

def index(request):
    mensagem = ""
    senha_erro = ""

    if request.method == "POST":
        if 'form_cliente' in request.POST:
            # Formulário do cliente
            nome = request.POST.get('nome')
            idade = request.POST.get('idade')
            email = request.POST.get('email')
            telefone = request.POST.get('telefone')
            qtd_pessoas = request.POST.get('qtd_pessoas')

            if nome and idade and email and telefone and qtd_pessoas:
                Pessoa.objects.create(
                    nome=nome,
                    idade=int(idade),
                    email=email,
                    telefone=telefone,
                    qtd_pessoas=int(qtd_pessoas)
                )
                mensagem = "Cadastro realizado com sucesso! Aguarde na lista de espera."
            else:
                mensagem = "Por favor, preencha todos os campos."

        elif 'form_senha' in request.POST:
            senha = request.POST.get('senha')
            if senha == "12345":
                return redirect('lista_espera')
            else:
                senha_erro = "Senha incorreta."

    # ✅ Buscar todas as pessoas para mostrar no template
    pessoas = Pessoa.objects.all()

    return render(
        request,
        "index.html",
        {
            "mensagem": mensagem,
            "senha_erro": senha_erro,
            "pessoas": pessoas  # <-- adicione esta linha
        }
    )
