"""
URL configuration for APP project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from .views import index, lista_espera, adicionar_pessoa, editar_pessoa, deletar_pessoa

urlpatterns = [
    path('', index, name='index'),
    path('lista/', lista_espera, name='lista_espera'),
    path('adicionar/', adicionar_pessoa, name='adicionar_pessoa'),
    path('editar/<int:pessoa_id>/', editar_pessoa, name='editar'),
    path('delete/<int:pessoa_id>/', deletar_pessoa, name='delete'),
]